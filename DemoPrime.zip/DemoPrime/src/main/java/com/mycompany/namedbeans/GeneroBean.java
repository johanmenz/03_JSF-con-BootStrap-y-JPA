package com.mycompany.namedbeans;

import java.util.List;

import javax.persistence.EntityManager;

import com.mycompany.entities.Genero;
import com.mycompany.repository.GeneroRepository;
import javax.enterprise.context.RequestScoped;


import javax.inject.Named;
import javax.persistence.PersistenceContext;

@Named
@RequestScoped
public class GeneroBean {

    @PersistenceContext
    private EntityManager entityManager;

    private List<Genero> generos = null;

    public List<Genero> getGeneros() {
        if (this.generos == null) {
            GeneroRepository repository = new GeneroRepository(entityManager);
            this.generos = repository.getGeneros();
        }

        return this.generos;
    }

}
